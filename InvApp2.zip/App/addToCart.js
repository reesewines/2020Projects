var foodList = [];
var price = 0;

function addToCart(){
    alert("Item added to cart");
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById('myInput');
    filter = input.value.toUpperCase();
    //ul = document.getElementById("myList");
    //var foodList = [];
  
    //foodList.push(document.getElementById.innerHTML("demo"));
    foodList.push(document.getElementById("item").innerHTML);
    console.log(foodList);
    localStorage.setItem("foodList", foodList);

    document.getElementById("demo").innerHTML = foodList;
}  


function pullFromCart() {
    console.log(foodList);
    foodList = localStorage.getItem("foodList");
    document.getElementById("demo").innerHTML ="Cart:"+foodList;
}

function getPrice(){
    for (i=0;i<foodList.length;i++)
        if(foodList[i]=="Mountain Dew"){
            price += 1;
        }
}
/*
<script>
document.getElementById("demo").innerHTML = 
'hi';
</script>*/

/*
function myFunction() {
  // Declare variables
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName('li');

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
*/